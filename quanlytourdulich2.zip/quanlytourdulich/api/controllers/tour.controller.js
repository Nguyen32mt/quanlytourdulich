const tour = require('../models/tour');

const tourController = {
    createTour: async (req, res) => {
        const newtour = new tour(req.body);
        try {
            const savedTour = await newtour.save();
            res.status(200).json({ savedtour });
        } catch (err) {
            console.log(err);
            res.status(500).json(err);
        }
    },
    gettour: async (req, res) => {
        try {
            const tour = await tour.find();
            return res.status(200).json(tour);
        } catch (err) {
            console.log(err);
            return res.status(500).json({ msg: err.message });
        }
    },
    deleteAllTour: async (req, res) => {
        try {
            const product = await tour.remove();
            res.status(200).json({message: true, product:product});
        } catch (err) {
            res.status(500).json(err);
        }
    }
}

module.exports = tourController;