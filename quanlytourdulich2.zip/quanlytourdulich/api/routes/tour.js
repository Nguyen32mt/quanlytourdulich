var express = require('express');
var router = express.Router();
const tourController = require('../controllers/tour.controller')


/* GET PBs. */
router.get('/', tourController.gettour);

/* Post PBs. */
router.post('/create-tour', tourController.createTour);

/* Delete PBs. */
router.delete('/delete-tour', tourController.deleteAllTour);

module.exports = router;
