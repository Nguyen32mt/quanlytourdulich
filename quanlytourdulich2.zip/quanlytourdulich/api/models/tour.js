const mongoose = require('mongoose');

const tourSchema = new mongoose.Schema(
    {
        tenTour: {
            type: String,
            require: true,
        },
        soKH: {
            type: Number,
            require: true,
        },
        lH:{
            type: String,
            require: true,

        }
       
    },
    { timestamps: true },
)
const tour = mongoose.model('tour', tourSchema)
module.exports = tour;