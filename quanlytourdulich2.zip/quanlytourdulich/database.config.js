const mongoose = require('mongoose');

const connecTDB = () =>{
    try{
        const connec = await mongoose.connect(process.env.MONGDB_URL)
    }catch(e){
        console.log('Error mongoose', e)
    }
}
module.exports = connecTDB
var http = require("http");
